import { expect, Page } from '@playwright/test';

async function waitForOnboarding(page: Page) {
  const onboarding = page.locator('.onboarding');
  const continueButton = page.getByRole('button', {
    name: /^Continue/i,
  });

  /*
   * Wait until APEX has actually left its hydration splash and rendered
   * onboarding. We deliberately inspect the DOM state rather than adding
   * arbitrary sleeps.
   */
  await expect
    .poll(
      async () =>
        page.evaluate(() => {
          const onboarding = document.querySelector('.onboarding');
          const continueButton = Array.from(
            onboarding?.querySelectorAll('button') ?? []
          ).find((button) =>
            /^Continue/i.test((button.textContent || '').trim())
          );

          return Boolean(onboarding && continueButton);
        }),
      {
        timeout: 20_000,
        intervals: [100, 250, 500],
        message: 'APEX onboarding did not render after hydration.',
      }
    )
    .toBe(true);

  await expect(onboarding).toBeVisible({
    timeout: 10_000,
  });

  await expect(continueButton).toBeVisible({
    timeout: 10_000,
  });

  return continueButton;
}

async function clearBrowserPersistence(page: Page) {
  await page.evaluate(async () => {
    try {
      localStorage.clear();
    } catch {
      // Ignore unavailable storage.
    }

    try {
      sessionStorage.clear();
    } catch {
      // Ignore unavailable storage.
    }

    /*
     * IndexedDB is not used by APEX's web persistence path, but clearing it
     * makes the helper safe if a future web adapter introduces it.
     */
    try {
      if ('indexedDB' in window && 'databases' in indexedDB) {
        const databases = await indexedDB.databases();

        await Promise.all(
          databases
            .filter((database) => Boolean(database.name))
            .map(
              (database) =>
                new Promise<void>((resolve) => {
                  const request = indexedDB.deleteDatabase(
                    database.name as string
                  );

                  request.onsuccess = () => resolve();
                  request.onerror = () => resolve();
                  request.onblocked = () => resolve();
                })
            )
        );
      }
    } catch {
      // Best-effort only.
    }

    /*
     * Prevent stale service-worker/cache state from affecting tests.
     */
    try {
      if ('serviceWorker' in navigator) {
        const registrations =
          await navigator.serviceWorker.getRegistrations();

        await Promise.all(
          registrations.map((registration) =>
            registration.unregister().catch(() => false)
          )
        );
      }
    } catch {
      // Best-effort only.
    }

    try {
      if ('caches' in window) {
        const cacheNames = await caches.keys();

        await Promise.all(
          cacheNames.map((cacheName) =>
            caches.delete(cacheName).catch(() => false)
          )
        );
      }
    } catch {
      // Best-effort only.
    }
  });
}

export async function resetApp(page: Page) {
  /*
   * Clear storage before the first application script can hydrate state.
   */
  await page.addInitScript(() => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {
      // Storage may not be available yet.
    }

    /*
     * IndexedDB is best-effort here. APEX's current web repository does not
     * use native SQLite in Playwright.
     */
    try {
      if ('indexedDB' in window && 'databases' in indexedDB) {
        void indexedDB.databases().then((databases) => {
          for (const database of databases) {
            if (!database.name) continue;

            try {
              indexedDB.deleteDatabase(database.name);
            } catch {
              // Continue.
            }
          }
        });
      }
    } catch {
      // Best-effort only.
    }
  });

  /*
   * Initial navigation.
   */
  await page.goto('/', {
    waitUntil: 'domcontentloaded',
  });

  /*
   * Clear anything created during the first document lifecycle.
   */
  await clearBrowserPersistence(page);

  /*
   * Reload so APEX starts from the genuinely empty state.
   */
  await page.reload({
    waitUntil: 'domcontentloaded',
  });

  /*
   * IMPORTANT:
   *
   * This is the ONLY place where we wait for onboarding hydration.
   * completeOnboarding() must consume the state produced here instead of
   * performing another independent hydration wait.
   */
  const continueButton = await waitForOnboarding(page);

  await expect(page.getByText('SETUP')).toBeVisible({
    timeout: 10_000,
  });

  /*
   * Give React one render opportunity after hydration before the next helper
   * begins interacting with the onboarding state.
   */
  await page.waitForFunction(() => {
    const onboarding = document.querySelector('.onboarding');
    const button = Array.from(
      onboarding?.querySelectorAll('button') ?? []
    ).find((candidate) =>
      /^Continue/i.test((candidate.textContent || '').trim())
    );

    return Boolean(button);
  });

  await expect(continueButton).toBeEnabled();
}

export async function completeOnboarding(page: Page) {
  /*
   * resetApp() has already synchronized hydration and onboarding.
   *
   * Do NOT call waitForOnboarding() here. Re-running the hydration
   * synchronization was the source of the previous failure.
   */
  const continueButton = page.getByRole('button', {
    name: /^Continue/i,
  });

  await expect(continueButton).toBeVisible({
    timeout: 10_000,
  });

  /*
   * Step 1 — Intro
   */
  await expect(continueButton).toBeEnabled();
  await continueButton.click();

  /*
   * Step 2 — Training experience
   */
  const beginner = page.getByRole('button', {
    name: 'Beginner',
  });

  await expect(beginner).toBeVisible({
    timeout: 10_000,
  });

  await expect(continueButton).toBeDisabled();

  await beginner.click();

  await expect(beginner).toHaveClass(/selected/);
  await expect(continueButton).toBeEnabled();

  await continueButton.click();

  /*
   * Step 3 — Training goal
   */
  const buildMuscle = page.getByRole('button', {
    name: /Build muscle/i,
  });

  await expect(buildMuscle).toBeVisible({
    timeout: 10_000,
  });

  await expect(continueButton).toBeDisabled();

  await buildMuscle.click();

  await expect(buildMuscle).toHaveClass(/selected/);
  await expect(continueButton).toBeEnabled();

  await continueButton.click();

  /*
   * Step 4 — Training schedule
   */
  const trainingDays = page.getByRole('button', {
    name: /4 days \/ week/i,
  });

  const sessionLength = page.getByRole('button', {
    name: /60 minutes/i,
  });

  await expect(trainingDays).toBeVisible({
    timeout: 10_000,
  });

  await expect(sessionLength).toBeVisible({
    timeout: 10_000,
  });

  await expect(continueButton).toBeDisabled();

  await trainingDays.click();

  await expect(continueButton).toBeDisabled();

  await sessionLength.click();

  await expect(continueButton).toBeEnabled();

  await continueButton.click();

  /*
   * Step 5 — Equipment
   */
  const build = page.getByRole('button', {
    name: /Build my APEX plan/i,
  });

  await expect(build).toBeVisible({
    timeout: 10_000,
  });

  await expect(build).toBeDisabled();

  for (const equipment of [
    'Machine',
    'Cable',
    'Dumbbell',
    'Barbell',
    'Bench',
    'Bodyweight',
  ]) {
    const equipmentButton = page.getByRole('button', {
      name: new RegExp(`^${equipment}`, 'i'),
    });

    await expect(equipmentButton).toBeVisible({
      timeout: 10_000,
    });

    await equipmentButton.click();
  }

  await expect(build).toBeEnabled();

  await build.click();

  /*
   * Onboarding completion updates React state and generates the initial plan.
   * Wait for the actual Home route rather than assuming the click is synchronous.
   */
  await expect(
    page.locator('[data-apex-route="home"]')
  ).toBeVisible({
    timeout: 20_000,
  });

  await expect(page.getByText('Training command center')).toBeVisible({
    timeout: 20_000,
  });
}

export async function installReducedMotion(page: Page) {
  /*
   * APEX stores reduced-motion inside preferences.reducedMotion.
   */
  const stateWritten = await page.evaluate(() => {
    const candidates = [
      'apex-state-v4',
      'apex-state',
      'apex-app-state',
      'apex-state-v5',
    ];

    for (const key of candidates) {
      const raw = localStorage.getItem(key);

      if (!raw) {
        continue;
      }

      try {
        const state = JSON.parse(raw);

        if (
          state &&
          typeof state === 'object' &&
          state.preferences &&
          typeof state.preferences === 'object'
        ) {
          state.preferences = {
            ...state.preferences,
            reducedMotion: true,
          };

          localStorage.setItem(key, JSON.stringify(state));

          return {
            key,
            reducedMotion: state.preferences.reducedMotion,
          };
        }
      } catch {
        // Continue searching.
      }
    }

    return {
      key: null,
      reducedMotion: false,
    };
  });

  expect(
    stateWritten.reducedMotion,
    `Could not locate a persisted APEX state containing preferences.reducedMotion. Keys checked: ${[
      'apex-state-v4',
      'apex-state',
      'apex-app-state',
      'apex-state-v5',
    ].join(', ')}`
  ).toBe(true);

  await page.reload({
    waitUntil: 'domcontentloaded',
  });

  await expect
    .poll(
      async () =>
        page.evaluate(() => {
          const keys = [
            'apex-state-v4',
            'apex-state',
            'apex-app-state',
            'apex-state-v5',
          ];

          for (const key of keys) {
            const raw = localStorage.getItem(key);

            if (!raw) {
              continue;
            }

            try {
              const state = JSON.parse(raw);

              if (
                state?.preferences &&
                state.preferences.reducedMotion === true
              ) {
                return true;
              }
            } catch {
              // Ignore malformed state.
            }
          }

          return false;
        }),
      {
        timeout: 10_000,
        message:
          'APEX did not persist preferences.reducedMotion=true after reload.',
      }
    )
    .toBe(true);

  const app = page.locator('.app');

  await expect(app).toBeVisible({
    timeout: 10_000,
  });

  await expect(app).toHaveClass(
    /(?:^|\s)reduce-motion(?:\s|$)/,
    {
      timeout: 10_000,
    }
  );
}

export async function assertNoHorizontalOverflow(page: Page) {
  const result = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    clientWidth: document.documentElement.clientWidth,
    bodyScrollWidth: document.body.scrollWidth,
    bodyClientWidth: document.body.clientWidth,
  }));

  expect(
    result.scrollWidth,
    `Document horizontal overflow: ${result.scrollWidth}px > ${result.clientWidth}px`
  ).toBeLessThanOrEqual(result.clientWidth + 1);

  expect(
    result.bodyScrollWidth,
    `Body horizontal overflow: ${result.bodyScrollWidth}px > ${result.bodyClientWidth}px`
  ).toBeLessThanOrEqual(result.bodyClientWidth + 1);
}

export async function assertVisibleButtonsAreNotClipped(page: Page) {
  const failures = await page
    .locator('button:visible')
    .evaluateAll((buttons) => {
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;

      return buttons
        .map((button) => {
          const element = button as HTMLElement;
          const rect = element.getBoundingClientRect();
          const style = getComputedStyle(element);

          /*
           * Playwright's :visible means the element participates in layout
           * and is not hidden. It does not mean it is currently inside the
           * viewport.
           */
          const outsideViewport =
            rect.right <= 0 ||
            rect.left >= viewportWidth ||
            rect.bottom <= 0 ||
            rect.top >= viewportHeight;

          if (outsideViewport) {
            return null;
          }

          const tooSmall =
            rect.width < 28 ||
            rect.height < 28;

          const horizontallyClipped =
            rect.left < 0 ||
            rect.right > viewportWidth;

          const verticallyClipped =
            rect.top < 0 ||
            rect.bottom > viewportHeight;

          const isFixedOrSticky =
            style.position === 'fixed' ||
            style.position === 'sticky';

          const clipped =
            tooSmall ||
            (!isFixedOrSticky &&
              (horizontallyClipped || verticallyClipped));

          if (!clipped) {
            return null;
          }

          return {
            text: (element.textContent || '')
              .trim()
              .replace(/\s+/g, ' ')
              .slice(0, 120),
            aria: element.getAttribute('aria-label'),
            role: element.getAttribute('role'),
            width: rect.width,
            height: rect.height,
            left: rect.left,
            right: rect.right,
            top: rect.top,
            bottom: rect.bottom,
            display: style.display,
            position: style.position,
          };
        })
        .filter(Boolean);
    });

  expect(
    failures,
    JSON.stringify(failures, null, 2)
  ).toEqual([]);
}